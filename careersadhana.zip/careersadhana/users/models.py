# Using Django's built-in User model
# Additional user profile fields can be added here if needed
